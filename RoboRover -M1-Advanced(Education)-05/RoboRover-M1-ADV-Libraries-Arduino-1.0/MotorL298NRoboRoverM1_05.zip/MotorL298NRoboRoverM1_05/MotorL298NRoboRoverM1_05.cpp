﻿/*
Библиотека для драйвера моторов L298N в РобоРовер М1.
Версия v1.1

РОБОТЫ и НАБОРЫ ПО РОБОТОТЕХНИКЕ на МРобот! mrobot.by
http://www.mrobot.by

Разработчик Максим Массальский
Ник: maxxlife
E-mail: maxxlife@mrobot.by
*/

#include <Arduino.h>
#include "MotorL298NRoboRoverM1_05.h"

void Motors::attach()
{
  //Инициализация пинов мотордрайвера на выход
  pinMode(enA, OUTPUT);
  pinMode(enB, OUTPUT);
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(in3, OUTPUT);
  pinMode(in4, OUTPUT);
}

void Motors::write(int a, int b)
{
  if (a > 0)
  {
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    analogWrite(enA, a);
  }
  if (b > 0)
  {
    digitalWrite(in3, HIGH);
    digitalWrite(in4, LOW);
    analogWrite(enB, b);
  }

  if (a == 0)
  {
    //Левый мотор
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
    analogWrite(enA, 0);
  }
  if (b == 0)
  {
    //Правый мотор
    digitalWrite(in3, LOW);
    digitalWrite(in4, LOW);
    analogWrite(enB, 0);
  }
  if (a < 0)
  {
    a=abs(a);
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
    analogWrite(enA, a);
  }
  if (b < 0)
  {
    b=abs(b);
    digitalWrite(in3, LOW);
    digitalWrite(in4, HIGH);
    analogWrite(enB, b);
  }

}

