﻿#include <Arduino.h>
#include "SharpA21RoboRoverM1_05.h"


void Sharp::attach(int pinNumber)
{
  pinDistanceSharp = pinNumber;
}

int Sharp::read()
{
  double voltConst = 0.0048;
  double distance;
  double volts = analogRead(pinDistanceSharp) * voltConst;
  double val[40] = { 2.73, 2.34, 1.99, 1.76, 1.57, 1.42, 1.29, 1.20, 1.07, 1.00, 0.94, 0.88, 0.82, 0.79, 0.74, 0.71, 0.68, 0.65, 0.63, 0.61, 0.58, 0.55, 0.53, 0.50, 0.51, 0.49, 0.48, 0.47, 0.45, 0.44, 0.42, 0.41, 0.40, 0.39, 0.38, 0.37, 0.36, 0.33, 0.28, 0.26 };
  int cm[40] = { 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 90, 100, 110 };
  for (int i = 0; i < 40; i++)
  {
    if (val[i] <= volts)
    {
      distance = cm[i];
      break;
    }
    if (volts < 0.26)
    {
      distance = 120;
    }
  }
  if (volts > 3.00)
  {
    distance = 6;
  }
  return distance;
}
