#include <Arduino.h>
class Sharp
{
private:
	int pinDistanceSharp;
public:
	void attach(int);
	int read();
};

